from django.apps import AppConfig


class followConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'follow'
